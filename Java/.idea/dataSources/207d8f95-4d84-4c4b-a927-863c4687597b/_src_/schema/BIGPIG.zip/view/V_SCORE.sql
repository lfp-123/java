CREATE VIEW V_SCORE AS SELECT sname,
MAX(decode(cname,'语文',score,0)) 语文,
MAX(decode(cname,'数学',score,0)) 数学,
MAX(decode(cname,'英语',score,0)) 英语
FROM new_score GROUP BY sname
/
